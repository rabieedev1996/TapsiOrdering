﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatR;
using FluentValidation;
namespace $rootnamespace$
{
    #region Handler
    public class $itemname$QueryHandler: IRequestHandler< $itemname$Query, $itemname$Vm>
    {
        public async Task< $itemname$Vm> Handle($itemname$Query request, CancellationToken cancellationToken)
{
    return new $itemname$Vm
            { };
}
}
#endregion

#region Query
public class $itemname$Query: IRequest < $itemname$Vm >
    {}
#endregion

#region ViewModel
    public class $itemname$Vm
    {}
#endregion
}