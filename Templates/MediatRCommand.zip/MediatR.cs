﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatR;
using FluentValidation;
namespace $rootnamespace$
{
    #region Handler
    public class $itemname$CommandHandler: IRequestHandler< $itemname$Command, $itemname$Vm>
    {
        public async Task< $itemname$Vm> Handle($itemname$Command request, CancellationToken cancellationToken)
{
    return new $itemname$Vm
            { };
}
}
#endregion

#region Command
public class $itemname$Command: IRequest < $itemname$Vm >
    {}
    public class $itemname$CommandValidator: AbstractValidator < $itemname$Command >
    {
        public $itemname$CommandValidator()
        {
            //RuleFor(p => p.Param1)
            //    .NotEmpty().WithMessage("وارد کردن این فیلد اجباری است.");
        }
    }
#endregion

#region ViewModel
    public class $itemname$Vm
    {}
#endregion
}